<?php

namespace App\Http\Controllers\Apis\Controllers\getRegions;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class getRegionsRules extends Controller
{
    public static function rules(){

        return null ;

    }
}
