<?php
namespace App\Http\Controllers\Apis\Controllers\visitors;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Apis\Helper\helper;
use App\Http\Controllers\Apis\Controllers\index;
use App\Http\Controllers\Apis\Resources\objects;
use App\Models\users;

class visitorsController extends index
{
    public static function api()
    {
        $record=  users::createUpdate([
            'fireBaseToken'=>self::$request->deviceId,
            'lang'=>'ar'
        ]);
        return [
            "status"=>200,
            'apiToken'=>$record->api_token
        ];
    }
}